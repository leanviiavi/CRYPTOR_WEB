<?php
	namespace application\core;
	
	class CRYPTOR{
		
		//KEYS AND VALUES
		private $KEY;
		private $METHOD;
		private $FILE;
		private $FILE_LINKER;
		private $FILE_ID;
		private $connection;
		
		public function __construct(){
			//конструктор
				$config = require 'application/config/Db.php';

				$this->connection = mysqli_connect($config['host'],$config['user'],$config['password'],$config['name']);

				$this->connection->set_charset("utf8");
		}

		public function FILE($FILE){
			$this->FILE = $FILE;
		}

		public function E_FILE(){
			return $this->FILE;
		}
		public function FILE_LINKER($linker){
			$this->FILE_LINKER = $linker;
		}

		public function KEY($len){
			$KEY = '';
			for ($KEY_i = 0; $KEY_i <= $len; $KEY_i++){
				$KEY.=random_int(0, 9);
			}
			$this->KEY = $KEY;
		}

		public function GKEY(){
			return $this->KEY;
		}

		public function INIT_KEY($file_id){
		
			$query = "SELECT * FROM `keys`";

			$result = mysqli_query($this->connection, $query);
			while ($row = mysqli_fetch_array($result)){
				if ($row['id']==$file_id){
					$KEY=$row['Ключ шифрования'];
					break;
				}
			}
			$this->KEY = $KEY;
		}

		public function CONVERT($command){
			$this->FILE = file_get_contents($this->FILE_LINKER, true);
			if ($command=='encrypt'){
				$this->FILE = $this->encrypt($this->FILE);
			}
			if ($command=='decrypt'){
				$this->FILE = $this->decrypt($this->FILE);
			}
		}

		public function INIT_ID($linker){
			
			$query = "SELECT id FROM files WHERE `Группа`='".$_SESSION['group']."' AND `Ссылка`='".$linker."'";
			$result = mysqli_query($this->connection, $query);
			$result = mysqli_fetch_array($result);
			$this->FILE_ID = $result['id'];
			
			return $result['id'];
		}


		public function CREATE_KEY_WRITES(){
			$KEY = $this->KEY;
			$GROUP = $_SESSION['group'];
			$TRATE = $_SESSION['trate'];

			$query = "INSERT INTO keys (`Ключ шифрования`,`Группа`,`Доступ`) VALUES (".$KEY.",".$GROUP.",".$TRATE.")";
			$result = mysqli_query($this->connection, $query);
			if ($result){

			}else{

			}
		}
		
		// Encrypt Function
		public function encrypt($text) {
			mb_internal_encoding("UTF-8");
			$buff = '';
			for ($i=0; $i<=strlen($text);$i++){
				$buff .= chr((ord($text[$i]) ^ $this->KEY[$i%strlen($this->KEY)]));
			}
			$buff = substr($buff,0,-1);
			return $text;
		}

		public function decrypt($text){
			mb_internal_encoding("UTF-8");
			$buff = '';
			for ($i=0; $i<=strlen($text);$i++){
				$buff .= chr((ord($text[$i]) ^ $this->KEY[$i%strlen($this->KEY)]));
			}
			$buff = substr($buff,0,-1);
			return $text;
		}

	}


?>