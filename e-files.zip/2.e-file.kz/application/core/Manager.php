<?php

namespace application\core;

use application\models\ManagerModel;

class Manager{
	private $managerModel;
	private $init;
	private $errors = 0;
	public function __construct(){
		$this->managerModel = new ManagerModel;
		//$this->initUserFiles();

	}
	
	private function printDocType($fileType){
		$typeLibrary = include('application/config/fileTypes.php');
		
		foreach ($typeLibrary as $type => $link) {
			if ($fileType==$type){
				return $link;
			}
		}
	}
	private function InitFileType($fileLink){
		$linkLength = strlen($fileLink);
		$fileType = '';
		for ($i = $linkLength; $i>0; $i--){
			if ($fileLink[$i]!='.'){
				$fileType = $fileLink[$i].$fileType;
			}else{
				return $fileType;
			}
		}
		return 'fileTypeError';
	}
	
	public function initCurrentFileByLink($link){
		
		$init = $this->managerModel->initCurrent($link);
		
		if ($init){
			include "application/views/file-manager/currentForm.php";
		}else{
			print("<h1 class='error-title'>Не удалось найти файл</h1>");
		}
		
	}
	
	public function initUserFiles(){
		$init = $this->managerModel->InitCOM();
		if ($init == "model error"){
			print("<h3 class='error-title'>Вы не находитесь в данной группе!</h3>");
			$this->errors++;
		}else if (mysqli_num_rows($init)<1){
			//print($init);
			print("<h3 class='error-title'>В данной группе пока нет файлов!</h3>");
			$this->errors++;
		}
		if ($init && $this->errors==0){
			print("<h3 class='error-title files'>Список файлов группы: ".$_SESSION['group']."</h3>");
			print("<div class='file-list'>");
			while ($row = mysqli_fetch_array($init)){
				
				//load document type
				if (file_exists($row['Ссылка'])){
					$docType = $this->printDocType($this->InitFileType($row['Ссылка']));
				}else{
					$docType = 'none';
				}
				
				
				print('<div class="file"><form action="/files/current" method="post"><img src="/public/images/types/'.$docType.'" alt="dt"/>');
				print('<input type="text" name="link" value="'.$row['Ссылка'].'" hidden/>');
				print('<h3>('.$row['Группа'].') - '.$row['Наименование'].' ('.$row['Создатель'].')</h3>');
				print('<button class="btn btn-success pull-right" type="submit">К файлу</button>');
				print('</form><hr></div>');
			}
			print("</div>");
		}else{
			
		}
	}
	
}





?>