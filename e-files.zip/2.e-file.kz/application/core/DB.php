<?php

namespace application\core;

use PDO;

class DB{

	protected $db;

	public function __construct(){
		//конструктор
		$config = require 'application/config/Db.php';

		$this->db = new PDO('mysql:host='.$config['host'].';dbname='.$config['name'].';charset=utf8', $config['user'], $config['password']);

	}


	public function query($sql, $params = []){
		//запрос
		$stat = $this->db->prepare($sql);
		if (!empty($params)){
			foreach ($params as $key => $val) {
				$stat->bindValue(':'.$key,$val);
			}
		}
		$stat->execute();
		return $stat;
	}


	public function row($sql, $params = []){
		$result = $this->query($sql,$params);
		return $result->fetchAll(PDO::FETCH_ASSOC);
	}

	public function column($sql, $params = []){
		$result = $this->query($sql,$params);
		return $result->fetchColumn(1);		
	}

	//$sql = "FROM * SELECT *";





}

