<?php

namespace application\core;

class Router
{
	
	public function __construct()
	{
		$this->route();
	}

	public function route(){
		$config = require_once ('application/config/routes.php');
		$url = trim($_SERVER['REQUEST_URI'], '/');

		foreach ($config as $route => $params) {
				if ($url==$route){
					require_once ('application/views/'.$params['action'].'.php');
					exit();
				}
			}
		
		
		require_once ('application/views/error/404.php');
	} 
}