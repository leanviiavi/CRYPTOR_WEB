<section>
	<div class="container-fluid" style="background-image: url('https://i.pinimg.com/originals/94/8e/31/948e31d8046c8b13f52afe071c19b756.gif'); height: 500px;">
		<div class="row">
			<div class="col-md-13">
				<div class="error-title" style="background-color: white; width: 50%; display: block; margin: 100px auto;">
					<h1>404 ERROR</h1>		
					<h4>Данная страница отсутствует!</h4>			
				</div>
			</div>
		</div>
	</div>
</section>