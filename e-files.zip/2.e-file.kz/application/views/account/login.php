<section>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-13">
				<div class="lp">
					<div class="login-pane">
						<form action="/account/auth" method="post">
							<input type="text" name="login" placeholder="Логин">
							<input class="password" type="password" name="password" placeholder="Пароль">
							<button type="submit">Войти</button>
	 					</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
