<?php
session_start();
use application\models\Auth;

$auth = new Auth;

$login = $_POST['login'];
$password = $_POST['password'];

$auth->login($login, $password);

?>