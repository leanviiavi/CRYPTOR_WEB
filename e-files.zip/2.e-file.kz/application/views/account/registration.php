<section>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-13">

				<h5 class="title" style="text-align: center;">Регистрация пользователя</h5>

				<?php

					use application\models\RegistrationModel;

					$REGISTRATION = new RegistrationModel();

					if (!empty($_POST)){
						$REGISTRATION -> RegistrationForm();
					}

				?>
				<form action="" method="post" class="reg-form">
					<h5>Логин</h5><input type="text" name="registrationLogin">
					<h5>Пароль</h5><input type="password" name="registrationPassword">
					<h5>ФИО</h5><input type="text" name="username">
					<h5>Номер телефона</h5><input type="phone" name="phone">
					<h5>Год рождения</h5><input type="number" name="year">
					<h5>Месяц</h5><input type="number" name="month">
					<h5>День</h5><input type="number" name="day">
					<h5>Группа</h5><input type="text" name="group">
					<h5>Допуск</h5><input type="text" name="level" value="2" hidden>
					<button class="btn btn-submit">Зарегистрироваться</button>
				</form>
			</div>
		</div>
	</div>
</section>