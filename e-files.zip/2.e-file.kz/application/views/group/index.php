<?php
	session_start();
use application\models\Group;
if ($_SESSION['user']!=''){
	$GROUP = new Group();
	$GROUP->loadGroupData();
	$GROUP->fileList();
}else{
	print("<h1 class='title' style='display: block; width: 100%; color: red;'>Авторизуйтесь для работы</h1>");
}

?>

