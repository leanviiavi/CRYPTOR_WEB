	<div class="upload-info upload-gif">
	</div>

	<div class="upload-gif-contant">
		<img src="../../public/images/prev/upload.gif">
	</div>

<?php
use application\core\CRYPTOR;
//include('application/views/header.php');


    echo "<form action='../../' class='centereds' method='post'><button class='btn btn-success centereds' style='margin-top: 200px;'>На главную</button></form>";

?>




