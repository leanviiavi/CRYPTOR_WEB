<?php if ($_SESSION['user']!=''): ?>
<section>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-13">
				<div class="upload-pane centered">
					
					<form action="/file/upload/" class="" method="post" enctype="multipart/form-data">
						<input type="text" name="upload" hidden style="visibility: hidden;">
						<input id="fileToUpload" name="fileToUpload" type="file" class="inputfile">
						<label for="fileToUpload">Выбрать файл</label>
						<button type="submit" class="btn btn-success upload"><h6>Загрузить</h6></button>
					</form>
				
				</div>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
<?php

	use application\core\Manager;



	
	$manager = new Manager;
	
	$manager->initUserFiles();
	



?>