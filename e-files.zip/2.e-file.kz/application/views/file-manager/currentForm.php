<section>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-13">
					<?php if ($init): ?>
						<h1 style="text-align: center;"><?php echo $init['Наименование']; ?></h1>
						<form action="/files/download" method="post" style="text-align: center;">
							<input type="text" name="linkers" value="<?php echo $init['Ссылка']; ?>" hidden/>
							<button class="btn btn-success" type="submit">Скачать файл</button>
						</form>
					<?php endif; ?>
				</div>
			</div>
		</div>
</section>