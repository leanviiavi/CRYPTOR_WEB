<?php
	
	use application\core\Manager;
	
	$manager = new Manager();
	
	if (!empty($_POST['link'])){
		$manager->initCurrentFileByLink($_POST['link']);
	}
	


?>