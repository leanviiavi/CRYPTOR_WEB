<?php use application\Models\ManagerModel;
if (isset($_POST['linkers'])){
	  	exit;
	  } 
	  use application\core\CRYPTOR;
	  
	 
?>
<div class="upload-manager">

	<div class="upload-gif-contant">
		<img src="../../public/images/prev/upload.gif">
		<h1 class="title centereds">Идеи загрузка файла</h1>
		<h6 class="title centereds">Пожалуйста подождите</h6>
	</div>
	<div class="upload-info upload-gif">
		<?php //verefication user




			$uploaddir = './public/files/';
			$uploadfile = $uploaddir . basename($_FILES['fileToUpload']['name']);

			$ver = 0;
			$fileName = basename($_FILES['fileToUpload']['name']);

			if (move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $uploadfile)) {
	
				$manager = new ManagerModel;

				$CRYPTED_FILE_TEXT = '';
				$CRYPTOR = new CRYPTOR();
				$CRYPTOR->KEY(1);

				$FILE_LINKER = $uploadfile;
				$CRYPTOR->FILE_LINKER($FILE_LINKER);
				
			        $FILE_BUFF = readfile($uploadfile, false);
			        $CRYPTOR->FILE($FILE_BUFF);
			        $CRYPTOR->CONVERT('encrypt');
			        $CRYPTED_FILE_TEXT .= $CRYPTOR->E_FILE();
			    
			  	$handler = fopen($uploadfile, 'w');
			  	

				if (file_put_contents($uploadfile, $CRYPTED_FILE_TEXT)) {
					$CRYPTOR->CREATE_KEY_WRITES();
				}

				$key = 1;
	
				$uploadResult = $manager->uploadFile($fileName, $key, $_SESSION['group'], $_SESSION['user']);

				if ($uploadResult){
					$ver = 1;
				}else{
					$ver = 0;
					exit;
				}

				

				   
			} else {
			    echo '<h3 class="title">Ваш файл не был загружен!</h1>
					<h3 class="title error"><a href="../../">Вернуться на главную страницу</a></h3>';
			    exit;
			}


	

		?>
		<?php if ($ver == 1): ?>

			 	<script type="text/javascript">document.location.href="../../files/home";</script>

		<?php endif; ?>
	</div>
</div>