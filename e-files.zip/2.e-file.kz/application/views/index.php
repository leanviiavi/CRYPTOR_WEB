<?php session_start(); ?>



<?php
	
	if ($_SESSION['user']!=''){
		
		//load levels libxml_clear_errors
		$levels = include('application/config/Levels.php');
		$level = '';
		foreach ($levels as $lev => $id){
			if ($_SESSION['trate']==$id){
				$level = $lev;
			}
		}
		
		print("<div class='user-info'>");
		print("<h5>Вы авторизованы как: ".$_SESSION['user']."</h5>");
		print("<h6>Группа: ".$_SESSION['group']."</h6>");
		print("<h6>Уровень допуска: ".$level."</h6>");
		print("<h6>Тип пользователя: ".$_SESSION['level']."</h6>");
		print("</div>");
	}
	
	

?>


<!DOCTYPE html>
<section>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-13">
				<h1 style="text-align: center;">Новостной контент</h1>
			</div>
		</div>
	</div>
</section>
