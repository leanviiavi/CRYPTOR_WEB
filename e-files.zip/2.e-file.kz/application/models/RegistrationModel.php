<?php

	namespace application\models;

	/**
	 * 
	 */
	class RegistrationModel
	{
		
		private $connection;
		
		
		public function __construct(){
			//конструктор
				$config = require 'application/config/Db.php';

				$this->connection = mysqli_connect($config['host'],$config['user'],$config['password'],$config['name']);

				$this->connection->set_charset("utf8");

		}

		public function RegistrationForm(){

			//Собираем запрос из данных в POST

			$login = $_POST['registrationLogin'];
			$password = $_POST['registrationPassword'];
			$registrationIP = $_SERVER['REMOTE_ADDR'];
			$username = $_POST['username'];
			$phone = $_POST['phone'];
			$year = $_POST['year'];
			$month = $_POST['month'];
			$day = $_POST['day'];
			$group = $_POST['group'];
			$level = $_POST['level'];

			$registrationIndex = 0;

			$query = "INSERT INTO `users` (`ФИО`,`Номер`,`Почта`,`Пароль`,`Подтверждение`,`Год`,`Месяц`,`День`,`Статус`,`Бонусы`,`Группа`,`Допуск`,`индексРегистрации`,`IP`)
			VALUES ('".$username."','".$phone."','".$login."','".$password."',0,".$year.",".$month.",".$day.",'user',0,'".$group."','".$level."',".$registrationIndex.",'".$registrationIP."')";

			$result = mysqli_query($this->connection, $query);

			if ($result){
				//Данные успешно улетели в базу
				print("<h3 class='title'>Вы успешно зарегистрировались</h3>");
			}else{
				//Ошибка данных
				print("<h3 class='title'>Произошла ошибка</h3>");
			}

		}

	}

?>