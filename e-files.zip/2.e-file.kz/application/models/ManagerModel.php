<?php

namespace application\models;

class ManagerModel{
	
	private $connection;
	private $userGroup;
	
	public function __construct(){
		//конструктор
			$config = require 'application/config/Db.php';

			$this->connection = mysqli_connect($config['host'],$config['user'],$config['password'],$config['name']);

			$this->connection->set_charset("utf8");

	}
	
	
	public function InitCOM(){
		//init session for user by group
		$this->$userGroup = $_SESSION['group'];
		$result = $this->loadList();

		return $result;
	}
	
	public function InitCurrent($link){
		$this->$userGroup = $_SESSION['group'];
		$query = "SELECT * FROM files WHERE `Группа`='".$this->$userGroup."' AND `Уровень`<=".$_SESSION['trate']."";
		$result = mysqli_query($this->connection, $query);
		while ($res = mysqli_fetch_array($result)){
			if ($res['Ссылка']==$link){
				return $res;
			}
		}
	}
	public function loadList(){
		$query = "SELECT * FROM files WHERE `Группа`='".$this->$userGroup."' AND `Уровень`<=".$_SESSION['trate']."";
		$result = mysqli_query($this->connection, $query);
		if ($result){
			return $result;
		}else{
			return "model error";
		}
	}

	public function uploadFile($filename, $key, $group, $username){

		$query = "SELECT * FROM `users` WHERE `Группа`='".$group."' AND `ФИО`='".$username."'";
		$userinfo = mysqli_query($this->connection, $query);

		if ($userinfo){
			$userinfo = mysqli_fetch_array($userinfo);
			$userlevel = $userinfo['Допуск'];
			$link = './public/files/'.$filename;

			$query = "INSERT INTO `files` (`Наименование`,`Создатель`,`Группа`,`Уровень`,`Ссылка`,`Ключ`) VALUES ('".$filename."','".$username."','".$group."',".$userlevel.",'".$link."',".$key.")";
			$result = mysqli_query($this->connection, $query);
			if ($result)
				return 1;
		}else{
			return 0;
		}
		
	}
	
}



?>