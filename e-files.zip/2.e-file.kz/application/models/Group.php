<?php


namespace application\models;

class Group{

	private $connection;
	private $userGroup;
	
	public function __construct(){
		//конструктор
			$config = require 'application/config/Db.php';

			$this->connection = mysqli_connect($config['host'],$config['user'],$config['password'],$config['name']);

			$this->connection->set_charset("utf8");

	}

	public function loadGroupData(){

		//здесь прогружаем все данные о группе

		$query = "SELECT * FROM `users` WHERE Группа='".$_SESSION['group']."'";
		$result = mysqli_query($this->connection, $query);


		if ($result) {

			print("<h5 class='group-group-list'>Участники группы:</h5>");
			while ($row = mysqli_fetch_array($result)){

				print("<div class='group-list'><ul>");
				print("<li><h6>ID: ".$row['id']." </h6></li>");
				print("<li><h6>ФИО: ". $row['ФИО'] ." </h6></li>");
				print("</ul></div>");

			}
		}

	}

	public function fileList(){

		//Загружаем данные о файлах группы

		$query = "SELECT * FROM files";
		$result = mysqli_query($this->connection, $query);

		if ($result){
			$COUNT_OF_FILES = mysqli_num_rows($result);
			$FILES_NAME = [];
			$FILES_ID = [];
			$FILES_AUTHOR = [];
			$i=0;
			while ($row = mysqli_fetch_array($result)){
				$FILES_NAME[$i] = $row['Наименование'];
				$FILES_ID[$i] = $row['id'];
				$FILES_AUTHOR[$i] = $row['Создатель'];
				$i++;
			}

			print("<h5 class='group-group-list'>Данные о файлах группы</h5>");
			for ($i=0; $i<count($FILES_NAME); $i++){
				print("<div class='group-list'><ul>");
				print("<li><h6>ID: ".$FILES_ID[$i]." </h6></li>");
				print("<li><h6>Название файла: ".$FILES_NAME[$i]." </h6></li>");
				print("<li><h6>Автор: ".$FILES_AUTHOR[$i]." </h6></li>");
				
				print("</ul></div>");
			}
		}


	}

}



?>