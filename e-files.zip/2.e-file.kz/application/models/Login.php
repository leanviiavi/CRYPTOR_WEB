<?php

use application\core\DB;

/**
 * login class
 */
class Login extends DB
{
	
	public function __construct()
	{
		$this->login();
	}

	public function login(){
		if (isset($_POST)){
			$login = $_POST['login'];
			$pass = $_POST['password'];
			$res = $this->query("SELECT * FROM `users` WHERE `Почта` = '".$login."' AND `Пароль` = '".$pass."'");
			if (mysqli_num_rows($res) > 0){
				$row = mysqli_fetch_array($res);
				$_SESSION['user']=$row['Статус'];
				$_SESSION['username']=$row['ФИО'];
				$_SESSION['email']=$row['Почта'];
				$_SESSION['phone']=$row['Номер'];
				$_SESSION['id']=$row['id'];
				header("location: ../../");
			}else{
				header("location: /?notuser");
			}
			
		}
		
	}
}