<?php
	namespace application\models;
	/**
	 * @auth class
	 */
	class Auth
	{

		private $login;
		private $password;

		private $connection;
		
		public function __construct()
		{
			//конструктор
			$config = require 'application/config/Db.php';

			$this->connection = mysqli_connect($config['host'],$config['user'],$config['password'],$config['name']);

			$this->connection->set_charset("utf8");

		}

		public function login($login,$password){
			$query = "SELECT * FROM users WHERE `Почта`='".$login."' AND `Пароль`='".$password."'";
			$result = mysqli_query($this->connection, $query);
			if ($result){
				if (mysqli_num_rows($result) > 0){
					$row = mysqli_fetch_array($result);
					$_SESSION['user'] = $row['ФИО'];
					$_SESSION['level'] = $row['Статус'];
					$_SESSION['group'] = $row['Группа'];
					$_SESSION['trate'] = $row['Допуск'];
					print("<script>document.location.href='/';</script>");
				}else{
					print("<script>document.location.href='/account/login/no-user';</script>");
				}
			}else print("<script>document.location.href='/sql';</script>");
		}

	}

?>