<?php

return [
	'host' => 'localhost',
	'name' => 'e-file',
	'user' => 'mysql',
	'password' => 'mysql',
];