<?php

return [
	'doc' => 'doc.jpg',
	'ppt' => 'doc.jpg',
	'docx' => 'doc.jpg',
	'txt' => 'doc.jpg',
	'pdf' => 'pdf.jpg',
	'jpg' => 'jpg.jpg',
	'xlsx' => 'xlsx.jpg',
	'xls' => 'xlsx.jpg',
	'none' => 'none.jpg',
];