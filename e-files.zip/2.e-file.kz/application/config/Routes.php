<?php


return [
	'' => [
		'controller' => 'main',
		'action' => 'index',
	],
	'index.php' => [
		'controller' => 'main',
		'action' => 'index',
	],


	// account

	'account/login' => [
		'controller' => 'account',
		'action' => 'account/login',
	],
	'account/auth' => [
		'controller' => 'account',
		'action' => 'account/auth',
	],
	'account/deauth' => [
		'controller' => 'account',
		'action' => 'account/deauth',
	],
	'account/login/no-user' => [
		'controller' => 'account',
		'action' => 'account/no-user',
	],
	'account/registration' => [
		'controller' => 'account',
		'action' => 'account/registration',
	],

	// file manager
	
	'files/user' => [
		'controller' => 'file-manager',
		'action' => 'file-manager/manager',
	],
	'files/current' => [
		'controller' => 'file-manager',
		'action' => 'file-manager/current',
	],
	'files/download' => [
		'controller' => 'file-manager',
		'action' => 'file-manager/download',
	],
	'file/upload' => [
		'controller' => 'file-manager',
		'action' => 'file-manager/upload',
	],
	'files/home' => [
		'controller' => 'file-manager',
		'action' => 'file-manager/gotoHome',
	],
	'files/dl_save.php' => [
		'controller' => 'file-manager',
		'action' => 'file-manager/dl_save',
	],

	//group
	'group' => [
		'controller' => 'group',
		'action' => 'group/index',
	],




	
	// admin


	'admin' => [
		'controller' => 'admin',
		'action' => 'admin/index',
	],

	
	
	
];