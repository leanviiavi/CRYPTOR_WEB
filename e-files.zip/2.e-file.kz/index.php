<?php session_start(); ?>
<?php

	if (isset($_POST['linkers'])){

		ob_end_clean();
 
		$file = $_POST['linkers'];
		 
		header('Content-Description: File Transfer');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename=' . basename($file));
		header('Content-Transfer-Encoding: binary');
		header('Content-Length: ' . filesize($file));
		 
		readfile($file);
		exit();

	}

?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="/bootstrap-3.3.7-dist/css/bootstrap.css" >
	<link rel="stylesheet" href="/bootstrap-3.3.7-dist/css/font-awesome.min.css" >
	<link rel="stylesheet" type="text/css" href="/public/style/main.css">
	<title>leimans store model</title>
</head>
<body>

		<section>
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-13">
						<div class="header">
							<div class="links">
								
								<?php if (empty($_SESSION['user'])) echo '<a href="/account/login">Войти</a>'; ?>
								<?php if (!empty($_SESSION['user'])) echo '<a href="/account/deauth">Выйти</a>'; ?>
								<?php if (!empty($_SESSION['user']) || empty($_SESSION['user'])) echo '<a href="/account/registration">Регистрация</a>'; ?>
								
							</div>
						</div>
						<div class="header-contact">
							<div class="col-md-3">
								<h4>+7(777)777-77-77</h4>
								<h4>example@example.com</h4>
							</div>
							<div class="col-md-6">
								
								
								<h1 class="logo">CRYPTOR</h1>
								
							</div>
							<div class="col-md-3">
								<img class="logo-img" src="/public/images/prev/logo.png" />
							</div>
							
						</div>
						<div class="header-nav">
							<div class="nav-links">
								<a href="/">Личный кабинет</a>
								<a href="/files/user/">К файлам</a>
								<a href="/group">Группа</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		

	<?php

		spl_autoload_register(function($class){
			$path = str_replace('\\', '/', $class.".php");
			if (file_exists($path)){
				require ($path);
			}

		});


		use application\core\Router;

		$router = new Router;

	?>




</body>
</html>